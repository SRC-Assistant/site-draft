
  # SRC-Assistant website

  This is a code bundle for SRC-Assistant website. The original project is available at https://www.figma.com/design/0VETkjR1mxK5IhRfz8fExQ/SRC-Assistant-website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  